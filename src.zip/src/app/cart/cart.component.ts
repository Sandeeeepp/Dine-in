
import { Component, OnInit, Output } from '@angular/core';
import { AddToCartService } from '../add-to-cart.service';
import { Todo } from '../Menu/Todo';
import { io } from 'socket.io-client'

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  SOCKET_ENDPOINT = 'http://localhost:3000';
  socket: any;

  purchase_item!: Todo
  purchase_items!: Todo[]
  str: string[] = []
  n = 0; i = 1
  count = 0;
  qty: any
  asd!:Todo[]

  constructor(private addToCart: AddToCartService) {
    let localitem = localStorage.getItem("purchase_items")
    if (localitem == null) {
      this.purchase_items = []
    } else {
      this.purchase_items = JSON.parse(localitem);
    }


    this.purchase_items = []
    this.qty = 1
  }
  onClick(purchase_items: Todo) {
    console.log(purchase_items)
    const index = this.purchase_items.indexOf(purchase_items)
    this.purchase_items.splice(index, 1)
    localStorage.setItem("purchase_items", JSON.stringify(this.purchase_items))
    // let ind=this.str.indexOf(purchase_items.Name)
    // this.str.splice(ind,1)
  }


  pushing(data: Todo) {
    // if (this.str.indexOf(data.Name) == -1) {
    //   this.purchase_items.push(data)
    // }
    // this.str.push(data.Name)

    this.purchase_items.push(data)
  }
  ngOnInit(): void {
      
    this.setupSocketConnection();
    this.addToCart.messageSource.subscribe((message) => {
      this.purchase_item = {
        Name: message[0],
        Price: message[1],
        image: message[2],
        sale: false,

      }
      this.pushing(this.purchase_item)
    })
  }

  

  


  incrementQty() {

    this.qty += 1;
  }

  // decrement product qty
  decrementQty() {
    if (this.qty - 1 < 1) {
      this.qty = 1

    } else {
      this.qty -= 1;

    }

  }
  setupSocketConnection() {
    this.socket = io('http://localhost:3000');
    this.socket.on('message-broadcast', (data: Todo[]) => {
      if (data) {

        this.asd=data
        
      }
  })
}


SendMessage() {
  this.socket.emit('cart',this.purchase_item)
}
}
