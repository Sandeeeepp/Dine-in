import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CartComponent } from './cart/cart.component';
import { VegComponent } from './Menu/veg/veg.component';
import { NonVegComponent } from './Menu/non-veg/non-veg.component';
import { DrinksComponent } from './Menu/drinks/drinks.component';
import { DessertsComponent } from './Menu/desserts/desserts.component';
import { MenuComponent } from './Menu/menu.component';






@NgModule({
  declarations: [
    AppComponent,
    CartComponent,
    VegComponent,
    NonVegComponent,
    DrinksComponent,
    DessertsComponent,
    MenuComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
