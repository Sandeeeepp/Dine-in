import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DessertsComponent } from './Menu/desserts/desserts.component';
import { DrinksComponent } from './Menu/drinks/drinks.component';
import { NonVegComponent } from './Menu/non-veg/non-veg.component';
import { VegComponent } from './Menu/veg/veg.component';

const routes: Routes = [
  {path:'Veg',component:VegComponent},
  {path:'NonVeg',component:NonVegComponent},
  {path:'Drinks',component:DrinksComponent},
  {path:'Dessert',component:DessertsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
