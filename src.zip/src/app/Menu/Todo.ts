export class Todo{
    Name!:string
    Price!:any
    image!:string
    sale!:boolean
 
}