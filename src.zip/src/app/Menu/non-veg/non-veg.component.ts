import { Component, OnInit } from '@angular/core';
import { AddToCartService } from 'src/app/add-to-cart.service';
import { Todo } from '../Todo';

@Component({
  selector: 'app-non-veg',
  templateUrl: './non-veg.component.html',
  styleUrls: ['./non-veg.component.css']
})
export class NonVegComponent implements OnInit {

  todo!:Todo[]
  constructor(private addToCart:AddToCartService) {
    this.todo=[{
      Name: "Kasturi Chicken",
      Price: 190,
      sale:true,
      
      image:"../assets/kasturi.jpg"
    },
    {
      Name: "Chicken Kombdi",
      Price: 180,
      sale:false,
      image:"../assets/kombdi.jpg"
    },
    {
      Name: "Murgh Masallam",
      Price: 220,
      sale:false,
      image:"../assets/kombdi.jpg"

    }]
   }

  ngOnInit(): void {
  }
  submit(Name:string,Price:string){
    this.addToCart.messageSource.next([Name,Price])
  }

}
