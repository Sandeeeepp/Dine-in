import { Component, OnInit } from '@angular/core';
import { AddToCartService } from 'src/app/add-to-cart.service';
import { Todo } from '../Todo';

@Component({
  selector: 'app-drinks',
  templateUrl: './drinks.component.html',
  styleUrls: ['./drinks.component.css']
})
export class DrinksComponent implements OnInit {
  todo!:Todo[]
  constructor(private addToCart:AddToCartService) { 
    this.todo=[
      
        {
          Name: "Non Alcoholic Breezer",
          Price: 310,
          sale: true,
          image: "../assets/breezer.jpg"
        },
        {
          Name: "Pinacolada",
          Price: 190,
          sale: false,
          image: "../assets/pina.jpg"
        },
        {
          Name: "Virgin Mojito",
          Price: 120,
          sale: true,
          image: "../assets/mojito.jpg"
        },
        {
          Name: "Rose MocktailS",
          Price: 210,
          sale: false,
          image: "../assets/rose.jpg"
        }
      ]
    
  }
 

  ngOnInit(): void {
  }
  submit(name:string,Price:string){
    this.addToCart.messageSource.next([name,Price])

  }
  

}
