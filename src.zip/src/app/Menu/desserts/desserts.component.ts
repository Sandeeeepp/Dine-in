import { Component, OnInit } from '@angular/core';
import { AddToCartService } from 'src/app/add-to-cart.service';
import { Todo } from '../Todo';

@Component({
  selector: 'app-desserts',
  templateUrl: './desserts.component.html',
  styleUrls: ['./desserts.component.css']
})
export class DessertsComponent implements OnInit {
  todo!:Todo[]

  sanket="../assets/brownie.jpg"
  constructor(private addToCart:AddToCartService) { 
    this.todo=[
      {
        Name: "Chocolate Brownie",
        Price: 170,
        sale:true,
        image:"../assets/brownie.jpg",
      },
      {
        Name: "Cranberry Disco",
        Price: 120,
        sale:true,
        image:"../assets/disco.jpg"
      },
      {
        Name: "Al Faheedi Date Chocalte  Icecream",
        Price: 89,
        sale:false,
        image:"../assets/date.jpg"
      },
      {
        Name:"Falooda Mastani",
        Price:88,
        
        sale:false,
        image:"../assets/mastani.jpg"
        
      },
      {
        Name:"Belgian Waffle",
        Price:77,
        sale:true,
        image:"../assets/waffle.jpg"
      }
    ]
  }

  ngOnInit(): void {
  }
  submit(Name:string,Price:string){
    this.addToCart.messageSource.next([Name,Price])
  }
}
