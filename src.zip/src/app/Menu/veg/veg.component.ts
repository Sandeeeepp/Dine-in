import { Component, OnInit } from '@angular/core';
import { AddToCartService } from 'src/app/add-to-cart.service';
import { Todo } from '../Todo';

@Component({
  selector: 'app-veg',
  templateUrl: './veg.component.html',
  styleUrls: ['./veg.component.css']
})
export class VegComponent implements OnInit {

  todo!:Todo[]
  constructor(private addTocart:AddToCartService) { 
    this.todo=[
      {
        Name:"Paneer Tikka ",
        Price:100,
        
        sale:false,
        image:"../assets/restaurant-style-paneer-butter-masala-.jpg"
      },
      {
        Name:"Paneer Banjara",
        Price:120,
        
        sale:false,
        image:"../assets/banjara.jpg"
      }, 
      {
        Name:"Paneer Takatak",
        Price:220,
        
        sale:false,
        image:"../assets/paneertakatak.jpg"
      }, 
      {
        Name:"Veg Maratha",
        Price:110,
        sale:true,
        image:"../assets/maratha.jpg"
      }
    ]

    
  }

  ngOnInit(): void {
  }
  submit(Name:string,Price:string){
    this.addTocart.messageSource.next([Name,Price])
  }
}
